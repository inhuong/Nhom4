/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package poly.cafe.polycafe.dao;

import poly.cafe.polycafe.entity.Card;

/**
 *
 * @author Admin
 */
public interface CardDAO extends CrudDAO<Card, Integer>{
    
}
