
package poly.cafe.polycafe.dao;

import poly.cafe.polycafe.entity.Category;

public interface CategoryDAO extends CrudDAO<Category, String>{
    
}
