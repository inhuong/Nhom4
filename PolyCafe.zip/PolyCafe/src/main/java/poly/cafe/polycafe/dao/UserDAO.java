
package poly.cafe.polycafe.dao;

import poly.cafe.polycafe.entity.User;

/**
 *
 * @author Admin
 */
public interface UserDAO extends CrudDAO<User, String>{
    
}
