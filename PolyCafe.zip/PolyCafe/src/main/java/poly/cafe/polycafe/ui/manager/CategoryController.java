/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package poly.cafe.polycafe.ui.manager;

import poly.cafe.polycafe.dao.CrudController;
import poly.cafe.polycafe.entity.Category;

/**
 *
 * @author Admin
 */
public interface CategoryController extends CrudController<Category>{
    
}
